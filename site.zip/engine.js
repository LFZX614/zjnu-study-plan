(function(root){'use strict';
const NAMES={C:'古代文学',O:'现当代文学',F:'外国文学',T:'文学理论',H:'现代汉语'};
const ROTATION={0:['O'],1:['C','H'],2:['O','T'],3:['C','H'],4:['F','T'],5:['O','H'],6:['C','T']};
const DEFAULTS={mode:'normal',englishHeavy:false,lateLeave:false,tired:false,politicsLesson:35,newWordsMinutes:35,newWordsTarget:80,definitionMinutes:20,shortMinutes:40,essayMinutes:45,politicsChapter:'马原：资本主义经济制度'};
const toMinutes=t=>{const [h,m]=t.split(':').map(Number);return h*60+m};
const time=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
const addDays=(d,n)=>{const dt=new Date(d+'T12:00:00+08:00');dt.setUTCDate(dt.getUTCDate()+n);return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(dt)};
const prettyMinutes=n=>n>=60?`${Math.floor(n/60)}小时${n%60?`${n%60}分`:''}`:`${n}分钟`;
const weekday=d=>new Date(d+'T12:00:00+08:00').getUTCDay();
function piece(text,type,fallback){const re=new RegExp(type+'[：:]([^；。]+)');const m=(text||'').match(re);return m?m[1].slice(0,90):fallback}
function outline(text){return (text||'本轮高频主干与红卡').split('；')[0].replace(/全覆盖|，不新增专题/g,'').slice(0,100)}
function counts(min,unit,max){return Math.max(1,Math.min(max,Math.floor(min/unit)))}
function slot(id,subject,kind,start,minutes,label,detail,period,newContent=false){return{id,subject,kind,start,minutes,end:time(toMinutes(start)+minutes),label,detail,period,newContent}}
function makePlan(day,settings={},days=[]){
 const cfg={...DEFAULTS,...settings};const sunday=weekday(day.date)===0;const final=day.date==='2026-12-18';const buffer=!!day.buffer;const phase=day.phase;const subs=day.subs;const a=subs[0],b=subs[1]||'O';const late=cfg.mode==='late';const heavy=!!cfg.englishHeavy;const units=day.units||{};
 let capacity=buffer||final?240:phase==='第三轮'?420:480;if(cfg.tired)capacity=Math.min(capacity,360);
 let tasks=[],rescueSlots=[];
 const prev=days.find(d=>d.date===addDays(day.date,-1));
 const prevDesc=prev?`${prev.date.slice(5).replace('-','/')} ${prev.subs.map(s=>NAMES[s]).join('＋')}：先闭卷说出主干，再核对红卡。`:'用现有基础自测，不预设前一天已完成本计划。';
 if(sunday){
  const mins=buffer?35:45;tasks.push(slot('prev','ALL','review',late?'08:00':'05:00',buffer?20:35,'本周记忆热身',prevDesc,late?'上午':'清晨'));
  const starts=late?['08:45','09:40','10:35','15:55','19:00']:['08:00','08:55','09:50','14:00','14:55'];
  ['C','O','H','T','F'].forEach((s,i)=>tasks.push(slot('week-'+s,s,'review',starts[i],mins,`${NAMES[s]} · 本周闭卷复盘`,'只抽查本周已学：核心名解、简答要点、论述证据。目录未覆盖的项目仍标待覆盖，不默认完成。',i<3?'上午':i===4&&late?'晚上':'下午')));
  if(!buffer)tasks.push(slot('weekly','ALL','review','20:00',30,'五科红卡收口','各科最多保留3个优先难点，不新增内容。','晚上'));
  tasks.push(slot('today','ALL','review','23:10',20,'睡前轻回忆','回想本周最容易混的3个概念；说不出就标记，不加时。','回宿舍'));
  rescueSlots=buffer?[{start:'20:35',minutes:20}]:[{start:late?'11:20':'11:10',minutes:late?10:20},{start:'20:35',minutes:20}];
 }else{
  const base=late?[
   ['prev','ALL','review','08:00',35,'上午'],['main-outline',a,'outline','08:45',45,'上午'],['main-def',a,'definition','09:40',45,'上午'],['main-short',a,'short','10:35',30,'上午'],
   ...(!heavy?[['second-outline',b,'outline','15:10',40,'下午'],['second-def',b,'definition','16:00',30,'下午']]:[['second-def',b,'definition','15:55',35,'下午']]),
   ['old',b,'review','16:30',30,'下午'],['main-essay',a,'essay','19:00',45,'晚上'],['second-short',b,'short','19:55',30,'晚上'],['old-main',a,'review','21:05',25,'晚上'],['today','ALL','review','23:10',20,'回宿舍']
  ]:[['prev','ALL','review','05:00',35,'清晨'],['main-outline',a,'outline','08:00',45,'上午'],['main-def',a,'definition','08:55',45,'上午'],['main-short',a,'short','09:50',45,'上午'],['second-outline',b,'outline','10:45',25,'上午'],['second-def',b,'definition','14:00',45,'下午'],['second-short',b,'short','14:55',45,'下午'],['old',b,'review','15:50',30,'下午'],['main-essay',a,'essay','19:00',45,'晚上'],['old-main',a,'review','19:55',30,'晚上'],['today','ALL','review','23:10',20,'回宿舍']];
  const factor=(phase==='第三轮'?.85:1)*(final?.64:1)*(cfg.tired?.75:1);
  tasks=base.map(([id,s,kind,start,min,period])=>{
   min=Math.max(10,Math.floor(min*factor/5)*5);let label,detail;const unit=units[s]||'';const opening=phase==='第一轮'?'理解':'回忆';
   if(id==='prev'){label='复习前一天背过的内容';detail=prevDesc}
   else if(id==='today'){label='复习今天背过的内容';detail='合上资料回忆，不重背全文。3分钟说不出主干的内容，留下红卡明天处理。'}
   else if(id==='old'||id==='old-main'){label=`${NAMES[s]} · 旧卡复盘`;const last=days.filter(d=>d.date<day.date&&d.subs.includes(s)&&weekday(d.date)!==0).slice(-1)[0];detail=(last?`先回看 ${last.date.slice(5).replace('-','/')} 的同科任务；`:'先用已有知识自测；')+'再抽约一周前的同科旧卡，最多3个优先难点。'}
   else if(kind==='outline'){label=`${opening}主线 · ${NAMES[s]}`;detail=outline(unit)+'。限时形成时间轴/概念树；未读完的原文保留待覆盖标记，不把“看过标题”当作已背。'}
   else if(kind==='definition'){const num=counts(min,Number(cfg.definitionMinutes)||20,2);label=`名解 ${num}张 · `+piece(unit,'名解','本日高频术语与易混词');detail=`只选${num}张：界定、特征、代表/例子、意义。${phase==='第一轮'?'先理解，再闭卷说。':'先背已有卡，不开新资料。'}`}
   else if(kind==='short'){const num=counts(min,Number(cfg.shortMinutes)||40,1);label=`简答${min<(Number(cfg.shortMinutes)||40)?'主干':'骨架'} ${num}题 · `+piece(unit,'简答','本日高频比较与红卡');detail=min<(Number(cfg.shortMinutes)||40)?'这个时段短于你设定的完整用时，只完成定位与3关键词；例证和完整复述放进同科机动，不算整题已熟。':'完成1个问题的3—4点骨架，至少配1个例证；现汉说出分析依据。其余题留在选做池。'}
   else {label='论述提纲 1份 · '+piece(unit,'论述',s==='T'?'综合写作关系与作品例证':'本日主科高频框架');detail='只列定位、3个论点、各点作品证据和意义，不要求逐字全文默写。';}
   if(s==='T'&&['2026-12-03','2026-12-12'].includes(day.date)&&id==='second-short'){label='综合写作 · 整篇训练';detail='不少于1000字。使用本时段＋晚间主科提纲时段，共至少75分钟，另用旧卡时段30分钟自查；今日替换主科论述，不叠加。'}
   return slot(id,s,kind,start,min,label,detail,period,phase==='第一轮'&&day.date<='2026-11-20'&&!['review'].includes(kind));
  });
  // 写作训练优先保证连续75分钟，不把分散的半小时冒充整篇。
  if(['2026-12-03','2026-12-12'].includes(day.date)){
   tasks=tasks.filter(t=>!['main-essay','second-short','old-main'].includes(t.id));
   tasks.push(slot('writing','T','essay','19:00',75,'综合写作 · 1000字以上整篇训练','语言、文学、感觉/审美/生命关系中选一组，75分钟写作；今日取消主科论述提纲，避免叠加。','晚上'));
   tasks.push(slot('writing-check','T','review','20:25',30,'综合写作 · 自查与改提纲','核对概念、结构、作品证据和题干回应，记录3个最需要改的问题。','晚上'));
  }
  rescueSlots=[{start:late?'11:05':'11:10',minutes:late?25:20},{start:'20:35',minutes:30}];
  if(['2026-12-03','2026-12-12'].includes(day.date))rescueSlots=[{start:late?'11:05':'11:10',minutes:late?25:20},{start:'20:55',minutes:20}];
 }
 if(cfg.tired&&sunday){tasks=tasks.map(t=>({...t,minutes:Math.max(10,Math.floor(t.minutes*.8/5)*5)}));}
 const arranged=arrangeNinety(tasks,day,cfg);tasks=arranged.tasks;rescueSlots=arranged.rescueSlots;
 const balanced=rebalanceForeign(tasks,day,cfg);tasks=balanced.tasks;
 const political=politicsPlan(day,cfg);
 tasks=fitAfternoonPolitics(tasks,day,cfg);
 if(!late&&!heavy&&!sunday&&!['2026-12-03','2026-12-12'].includes(day.date))rescueSlots=[{start:'10:55',minutes:20},{start:'20:45',minutes:30}];
 tasks=restartFoundation(tasks,day);
 tasks=fitSixOClock(tasks,day,cfg);
 if(!late&&!sunday)rescueSlots=['2026-12-03','2026-12-12'].includes(day.date)?[{start:'21:00',minutes:20}]:[{start:'20:45',minutes:30}];
 if(weekday(day.date)===0&&!day.buffer){rescueSlots=rescueSlots.filter(s=>toMinutes(s.start)<1200);rescueSlots.push({start:'20:45',minutes:15});}
 let mandatory=tasks.reduce((s,t)=>s+t.minutes,0);
 // 若整篇训练超预算，缩减可压缩复盘块，绝不让预算悄悄超时。
 while(mandatory>capacity-15){const reducible=tasks.filter(t=>!['writing','writing-check'].includes(t.id)&&t.minutes>10).sort((x,y)=>y.minutes-x.minutes)[0];if(!reducible)break;reducible.minutes-=5;mandatory-=5;}
 tasks=clarifyTasks(tasks,day,cfg,days);
 let reserve=Math.min(rescueSlots.reduce((s,t)=>s+t.minutes,0),Math.max(0,capacity-mandatory));
 if(final)reserve=Math.min(reserve,20);
 let left=reserve;rescueSlots=rescueSlots.map(s=>{const m=Math.min(s.minutes,left);left-=m;return{...s,minutes:m,end:time(toMinutes(s.start)+m)}}).filter(s=>s.minutes>0);
 tasks=tasks.map(t=>({...t,end:time(toMinutes(t.start)+t.minutes),key:day.date+':'+t.id})).sort((x,y)=>toMinutes(x.start)-toMinutes(y.start));
 const extra=cfg.lateLeave&&!sunday&&!final?Math.min(25,capacity-mandatory-reserve):0;
 const extraSlots=extra?[{start:'17:00',minutes:Math.min(15,extra),end:time(1020+Math.min(15,extra))},...(extra>15?[{start:'17:30',minutes:extra-15,end:time(1050+extra-15)}]:[])]:[];
 const newMinutes=tasks.filter(t=>t.newContent).reduce((s,t)=>s+t.minutes,0);
 return{tasks,rescueSlots,mandatory,reserve,extra,capacity,newMinutes,reviewMinutes:mandatory-newMinutes,cfg,day,sunday,final,buffer,englishMinutes:heavy?90:30,breaks:arranged.breaks,sessions:arranged.sessions,extraSlots,politicsTasks:political.tasks,politicsMinutes:political.tasks.reduce((s,t)=>s+t.minutes,0),politicsMemoryDay:political.memoryDay,foreignFocus:balanced.foreignFocus};
}
function lifeSlots(plan){const c=plan.cfg;const late=c.mode==='late';const heavy=c.englishHeavy;const slots=[];
 if(!late){
  slots.push(['06:30—07:00','英语旧词复习','完整30分钟，优先易忘旧词']);
  slots.push([heavy?'14:00—15:30':'14:00—14:30',heavy?'英语阅读＋订正/听课':'两篇英语阅读',heavy?'共90分钟；当天专业课新背减量，不向深夜顺延':'约30分钟；早晨保留给前日复盘与旧词']);
  if(![2,4,6].includes(weekday(plan.day.date))||plan.final||heavy)slots.push(['07:00—07:20','晨间弹性／准备','补前日复盘卡点或休息；不新增背诵任务']);
  slots.push(['07:20—08:00','准备、出发、到馆','07:30出发，08:00开始专业课']);
 }else{
  slots.push(['07:00—08:00','起床、准备、到馆','前日专业课复盘移到08:00，上午新背相应缩减']);
  slots.push(['14:00—14:30','英语旧词复习','完整30分钟；不挤午休']);
  if(heavy){slots.push(['14:30—15:30','英语阅读＋订正/听课（前60分钟）','15:30休息15分钟']);slots.push(['15:45—16:15','英语订正收尾（30分钟）','英语阅读订正累计90分钟，之后再开始政治与专业课']);}
  else slots.push(['14:30—15:00','两篇英语阅读','约30分钟']);
 }
 slots.push(['11:30—14:00','午饭、午休、往返图书馆','其中保留30分钟午休；提前到馆的时间不默认追加新背']);slots.push([c.lateLeave?'17:40—19:00':'17:00—19:00','回宿舍、吃饭、洗澡、返馆','按19:00前后开始晚间学习，途中不塞任务']);slots.push(['21:30—22:00','收拾、回宿舍','21:40离馆，按约22:00到宿舍预留']);
 let start=22*60;const pm=Math.max(10,Number(c.politicsLesson)||35);const wm=Math.max(10,Number(c.newWordsMinutes)||35);
 if(c.tired||plan.final)slots.push([time(start)+'—'+time(start+pm),'休息／旧错题轻看（选做）','疲劳或考前末日不强制看网课，不挪作专业课补债']);start+=pm;
 slots.push([time(start)+'—'+time(start+wm),`英语新词 · ${c.newWordsTarget||80}个为目标`,`${wm}分钟；到时收手，不为凑数量推迟睡前收口`]);start+=wm;
 // 23:10—23:30专业复盘固定保留；晚间自定义超过70分钟必须显式提示，不能自动覆盖。
 slots.push(['23:30—23:50','拉伸','保留20分钟']);slots.push(['23:50—24:00','收尾、准备睡觉','夜间专业课不另安排补债']);
 for(const b of plan.breaks||[])slots.push([b.start+'—'+b.end,'休息15分钟','在馆学习约90分钟后休息；起身、喝水，不安排新任务']);
 return{slots:slots.map(([range,title,detail])=>({range,title,detail})).sort((a,b)=>toMinutes(a.range.split('—')[0])-toMinutes(b.range.split('—')[0])),nightOverflow:Math.max(0,pm+wm-70)};
}

function arrangeNinety(tasks,day,cfg){
 const late=cfg.mode==='late',heavy=cfg.englishHeavy,sunday=weekday(day.date)===0,writing=['2026-12-03','2026-12-12'].includes(day.date);
 const normal={prev:'05:00','main-outline':'08:00','main-def':'08:45','main-short':'09:45','second-outline':'10:30','second-def':'14:00','second-short':'14:45',old:'15:45','main-essay':'19:00','old-main':'19:45',today:'23:10'};
 const shifted={prev:'08:00','main-outline':'08:35','main-def':'09:45','main-short':'10:30','second-outline':'15:45','second-def':heavy?'16:00':'16:15',old:heavy?'16:30':'16:40','main-essay':'19:00','second-short':'19:45','old-main':'20:45',today:'23:10'};
 const weekly=late?{prev:'08:00','week-C':'08:35','week-O':'09:45','week-H':'10:30','week-T':'16:00','week-F':'19:00',weekly:'19:45',today:'23:10'}:{prev:'05:00','week-C':'08:00','week-O':'08:45','week-H':'09:45','week-T':'14:00','week-F':'14:45',weekly:'19:00',today:'23:10'};
 const map=sunday?weekly:late?shifted:normal;
 tasks=tasks.map(t=>({...t,start:map[t.id]||t.start}));
 if(late&&!sunday){for(const t of tasks){if(t.id==='second-outline')t.minutes=Math.min(t.minutes,30);if(t.id==='second-def')t.minutes=Math.min(t.minutes,heavy?30:25);if(t.id==='old')t.minutes=Math.min(t.minutes,heavy?30:20);}}
 if(writing){const check=tasks.find(t=>t.id==='writing-check');if(check){check.start='20:15';check.minutes=15;check.label='综合写作自查（上）';tasks.push({...check,id:'writing-check-2',start:'20:45',label:'综合写作自查（下）',detail:'休息后核对作品证据和题干回应，补正提纲，不再另写一篇。'});}}
 let rescueSlots=sunday?(day.buffer?[{start:'20:45',minutes:20}]:[{start:late?'11:15':'10:55',minutes:late?15:20},{start:'20:15',minutes:15}]):[{start:late?'11:00':'10:55',minutes:late?15:20},{start:'20:15',minutes:15},{start:late?'21:10':'20:45',minutes:late?20:15}];
 if(writing)rescueSlots=[{start:late?'11:00':'10:55',minutes:late?15:20},{start:'21:00',minutes:20}];
 const breaks=[{start:'09:30',end:'09:45'},{start:'15:30',end:'15:45'},{start:'20:30',end:'20:45'}];
 if(cfg.lateLeave&&!sunday&&day.date!=='2026-12-18')breaks.push({start:'17:15',end:'17:30'});
 const sessions=[{start:'08:00',end:'09:30',label:'上午第一组 · 90分钟'},{start:'09:45',end:'11:15',label:'上午第二组 · 90分钟'},{start:'14:00',end:'15:30',label:late?'下午第一组 · 英语/政治':'下午第一组 · 90分钟'},{start:'15:45',end:'17:00',label:'下午收口组 · 至17:00'},{start:'19:00',end:'20:30',label:'晚间第一组 · 90分钟'},{start:'20:45',end:'21:30',label:'晚间收口组 · 45分钟'}];
 return{tasks,rescueSlots,breaks,sessions};
}
function clarifyTasks(tasks,day,cfg,days){
 const lastQuestions=(subject,before)=>{const list=days.filter(d=>d.date<before&&d.questions?.[subject]);return list.at(-1)?.questions?.[subject];};
 return tasks.map(t=>{
  const q=day.questions?.[t.subject];
  if(t.kind==='definition'&&q){const n=counts(t.minutes,Number(cfg.definitionMinutes)||20,2);return{...t,label:`名词解释 · 必背${n}题`,items:q.definitions.slice(t.id==='foreign-def-3'?3:t.id==='foreign-def-2'?2:0,(t.id==='foreign-def-3'?3:t.id==='foreign-def-2'?2:0)+n),detail:`每题说出界定、主要特征、代表或例子。${t.minutes<(Number(cfg.definitionMinutes)||20)?'本时段先记主干，完整复述转同科机动。':'完成后合上资料复述。'}`};}
  if(t.kind==='short'&&q)return{...t,label:`简答题 · ${t.minutes<(Number(cfg.shortMinutes)||40)?'主干':'必背'}1题`,items:[t.id==='foreign-short-2'?(q.short2||q.short):q.short],detail:t.minutes<(Number(cfg.shortMinutes)||40)?'先记定位与3个关键词；完整例证转入同科机动，不把主干当成全文已熟。':'组织3—4个要点，配1个例子；现汉必须说明判断依据。'};
  if(t.kind==='essay'&&q)return{...t,label:t.id==='writing'?'论述题 · 整篇写作1题':'论述题 · 提纲1题',items:[q.essay],detail:t.id==='writing'?'不少于1000字；75分钟写作＋30分钟分段自查，替换主科论述，不叠加。':'只列总论点、3个分论点、每点作品证据及意义，不全文默写。'};
  if(t.id==='week-F'){const q=lastQuestions('F',day.date);return{...t,items:q?[...q.definitions.map(x=>'【已学名解】'+x),'【简答题：选1题】'+q.short+(q.short2?' 或 '+q.short2:''),'【论述提纲】'+q.essay]:[],detail:'只复盘最近周四已学外文。正常日先抽查4个名解，再选1道人物题和1个论述提纲；缓冲或疲劳日缩减，不新增章节。'};}
  if(t.id==='foreign-review'){const q=day.questions?.F;return{...t,label:'外国文学 · 旧卡抽测与对应表',items:(q?.reviewDefinitions||[]).map(x=>'【已学名解】'+x),detail:'从已学词条逐个抽查界定、代表或例证；卡住的才进入同科补救。首轮另核对作家作品对应表，不新增长答案。'};}
  if(t.kind==='review'&&!t.id.startsWith('writing-check')){
   let pool=[];
   if(t.id==='prev'){const prev=days.find(d=>d.date===addDays(day.date,-1));pool=Object.values(prev?.questions||{});}
   else if(t.id==='today')pool=Object.values(day.questions||{});
   else if(t.subject!=='ALL'){const q=lastQuestions(t.subject,day.date);if(q)pool=[q];}
   const items=pool.flatMap(q=>['【名词解释】'+q.definitions[0],'【简答题】'+q.short]).slice(0,4);
   return{...t,items,detail:t.detail+(items.length?' 下列为旧题抽查范围：每科先抽1个名解，再口述1道简答主干；不逐题重背全文。':'')};
  }
  return t;
 });
}


function rebalanceForeign(tasks,day,cfg){
 const foreignFocus=weekday(day.date)===4&&day.subs[0]==='F';const late=cfg.mode==='late',heavy=cfg.englishHeavy;
 if(foreignFocus){
  tasks=tasks.map(t=>{
   if(t.id==='second-def')return{...t,id:'foreign-def-2',subject:'F',kind:'definition'};
   if(t.id==='second-short')return{...t,id:'foreign-short-2',subject:'F',kind:'short'};
   if(t.id==='old-main')return{...t,id:'theory-maintain',subject:'T',kind:'definition'};
   return t;
  });
  // 正常周四用原本未绑定任务的半小时巩固外文；政治需补位时让出，不能占同一时段。
  if(!late&&!heavy)tasks.push(slot('foreign-review','F','review','16:15',cfg.tired?15:30,'外国文学 · 主干巩固','只回查今日与上周已学外文，不另扩展长答案。','下午'));
 }
 if(weekday(day.date)===0){tasks=tasks.map(t=>{
  if(t.id==='week-F')return{...t,start:late?'19:00':'16:00',minutes:cfg.tired?Math.min(t.minutes,35):(day.buffer?45:60),label:'外国文学 · 本周重点复盘',detail:'优先抽查本周周四已学名解、人物与框架；不给周日加新章。'};
  if(late&&t.id==='weekly')return{...t,start:'20:00'};
  return t;
 });}
 return{tasks,foreignFocus};
}
function politicsPlan(day,cfg){
 const w=weekday(day.date),memoryDay=[2,4,6].includes(w),late=cfg.mode==='late',heavy=cfg.englishHeavy,final=day.date==='2026-12-18',tasks=[];
 const chapter=String(cfg.politicsChapter||'马原：资本主义经济制度').slice(0,100);
 let start,total;const earlyMemory=!late&&!heavy&&memoryDay&&!final?20:0;
 if(!late&&!heavy){start=870;total=40;}
 else if(late&&!heavy){start=900;total=30;}
 else if(!late&&heavy){start=945;total=30;}
 else{start=975;total=30;}
 if(final)total=Math.min(total,20);
 const add=(id,kind,min,label,items,criteria)=>{tasks.push({...slot(id,'P',kind,time(start),min,label,'按实际进度接着做；不按日期强行跳章。','政治'),items,criteria,key:day.date+':'+id});start+=min;};
 const memo=memoryDay&&!final&&!earlyMemory?10:0;
 const remain=total-memo,quiz=Math.floor(remain/10)*5,correct=remain-quiz;
 add('politics-quiz','practice',quiz,final?'政治 · 已熟错题回看':w===0?'政治 · 本周错题重做':'政治 · 肖秀荣1000题',[
  w===0?'重做本周标错和犹豫题，到时停止，不开新题组。':final?'只看已做过的典型错题，不开新章。':chapter+'：从上次停下处做下一组，'+(quiz>=20?'约8—12道':quiz>=15?'约6—8道':'约4—5道')+'单选/多选；错得多就减半。'
 ],'完成限时题组，标出错题和猜对题；不以凑题量代替分析。');
 add('politics-correct','correction',correct,'政治 · 订正与回看',['每道错题记一句错因：概念不清／条件漏看／干扰项混淆。','只回查对应解析、徐涛课程片段或手册条目，不顺带展开新课。'],'能说出主要错题的判断依据，仍不清楚的标记到下次政治订正时段。');
 if(memo)add('politics-memory','memory',memo,'政治 · 肖秀荣背诵手册',['从已经学过的马原范围选择'+(memo>=20?'2个':'1个')+'小要点：读懂→合书复述→核对关键词。','先用本周错题对应的手册条目；还未理解的资本主义经济制度内容先不硬背。'],'合书说出所选要点的关键词；只记这一小组，不要求整页全文背熟。');
 if(earlyMemory)tasks.push({...slot('politics-memory','P','memory','07:00',20,'政治 · 肖秀荣背诵手册','早晨只背书，不安排政治选择题或订正；每周二、四、六短背诵。','清晨'),items:['从已学马原范围选2个小要点，读懂→合书复述→核对关键词。','优先上次错题对应的手册条目，不追整页全文。'],criteria:'能合书复述所选的2个要点；不以整页背完为标准。',key:day.date+':politics-memory'});
 const lesson=Math.max(10,Number(cfg.politicsLesson)||35);
 if(!cfg.tired&&!final)tasks.push({...slot('politics-lesson','P','lesson','22:00',lesson,'政治 · 徐涛网课（分段）','默认35分钟，跟随1000题当前章节；一节较长时分段，不能自动覆盖新词、睡前复盘与拉伸。','回宿舍'),items:[chapter+'对应课程；若基础未懂，先补对应知识点。'],criteria:'看完本次时间内的课程片段，能留下2—3条要点；不以整节是否结束为完成标准。',key:day.date+':politics-lesson'});
 return{tasks:tasks.sort((a,b)=>toMinutes(a.start)-toMinutes(b.start)),memoryDay};
}


function fitAfternoonPolitics(tasks,day,cfg){
 const late=cfg.mode==='late',heavy=cfg.englishHeavy,sunday=weekday(day.date)===0;
 if(!late&&!heavy){
  // 保留清晨英语和前日复盘，下午政治之后背名解，简答移至晚间。
  const hasEveningReview=tasks.some(t=>['old-main','theory-maintain'].includes(t.id));
  tasks=tasks.map(t=>{
   if(['second-def','foreign-def-2'].includes(t.id))return{...t,start:'14:40',minutes:Math.min(t.minutes,40),period:'下午'};
   if(t.id==='week-T')return{...t,start:'14:40',period:'下午'};
   if(['second-short','foreign-short-2'].includes(t.id))return{...t,start:'19:45',period:'晚上'};
   if(['old-main','theory-maintain'].includes(t.id))return{...t,start:'16:15',period:'下午'};
   if(t.id==='foreign-review'&&hasEveningReview)return{...t,start:'16:45',minutes:Math.min(t.minutes,15)};
   return t;
  });
 }
 if(late&&heavy){
  // 英语16:00收尾后先做政治，名解移到上午；主线阅读相应减量。
  tasks=tasks.map(t=>{
   if(['second-def','foreign-def-2','week-T'].includes(t.id))return{...t,start:'08:35',minutes:Math.min(t.minutes,30)};
   if(t.id==='main-outline'||sunday&&t.id==='week-C')return{...t,start:'09:05',minutes:Math.min(t.minutes,20)};
   return t;
  });
 }
 return tasks;
}


function fitSixOClock(tasks,day,cfg){
 const late=cfg.mode==='late',heavy=cfg.englishHeavy,sunday=weekday(day.date)===0,writing=['2026-12-03','2026-12-12'].includes(day.date);
 const factor=(day.phase==='第三轮'?.85:1)*(day.date==='2026-12-18'?.64:1)*(cfg.tired?.75:1);
 const scaled=n=>Math.max(10,Math.floor(n*factor/5)*5);
 if(late){if(heavy)tasks=tasks.map(t=>t.id==='old'||t.id==='restart-t-foundation'?{...t,start:'16:45',minutes:Math.min(t.minutes,15)}:t);return tasks;}
 tasks=tasks.map(t=>{
  if(t.id==='prev')return{...t,start:'06:00',minutes:Math.min(t.minutes,30)};
  if(sunday){if(t.id==='week-T')return{...t,start:heavy?'16:15':'15:10',minutes:Math.min(t.minutes,20)};if(t.id==='week-F')return{...t,start:heavy?'19:30':'15:45'};return t;}
  if(t.id==='second-outline')return{...t,start:'10:30',minutes:scaled(45),period:'上午'};
  if(['second-def','foreign-def-2'].includes(t.id))return{...t,start:heavy?'16:15':'15:10',minutes:scaled(20),period:'下午'};
  if(['second-short','foreign-short-2'].includes(t.id))return{...t,start:'19:45',minutes:scaled(heavy?30:45),period:'晚上'};
  if(t.id==='old'||t.id==='restart-t-foundation')return{...t,start:heavy?'16:35':'15:45',minutes:scaled(heavy?25:30),period:'下午'};
  if(t.id==='old-main'||t.id==='restart-o-foundation')return{...t,start:heavy?'16:35':'16:15',minutes:scaled(heavy?25:45),period:'下午'};
  if(t.id==='theory-maintain')return{...t,start:'16:15',minutes:scaled(25),period:'下午'};
  if(t.id==='foreign-review'&&!writing)return{...t,id:'foreign-def-3',kind:'definition',newContent:day.phase==='第一轮',start:'16:40',minutes:scaled(20),period:'下午'};
  return t;
 });
 if(heavy){const bridge=tasks.some(t=>t.id==='restart-o-foundation');tasks=tasks.filter(t=>!['theory-maintain','foreign-review','foreign-def-3'].includes(t.id)&&!(bridge?t.id==='old':t.id==='old-main'));}
 return tasks;
}

function restartFoundation(tasks,day){
 return tasks.map(t=>{
  if(day.date==='2026-10-29'&&t.id==='old')return{...t,id:'restart-t-foundation',kind:'bridge',newContent:true,label:'文论入门补齐 · 原复盘块内',items:['【名词解释主干】文学本体论：概念定位与关键词。','【简答骨架】说明世界、作家、作品、读者四要素的关系。'],detail:'这是原10/27入门内容。只在当前原复盘时段内补主干，不增加时长；不能闭卷说出的项保持待补。',criteria:'能说出文学本体论的定位，并列清四要素的关系；只完成主干，不视为整章背熟。'};
  if(day.date==='2026-10-30'&&t.id==='old-main')return{...t,id:'restart-o-foundation',kind:'bridge',newContent:true,label:'现代文学入门补齐 · 原复盘块内',items:['【名词解释识记】文学研究会、创造社：成立背景、主张与代表作家。','【简答主干】五四文学革命的主要内容与文学史意义。'],detail:'从原10/27接续，只做定位、关键词和3点骨架。现代性长论述降为识记，不再叠加整篇背诵；未熟项仍需同科补救。',criteria:'能辨认两社团并说出五四文学革命的3个要点；未掌握内容保持待补。'};
  return t;
 });
}

function nextEligible(item,fromDate,days){return days.find(d=>d.date>=fromDate&&(weekday(d.date)===0||d.subs.includes(item.subject)))||null}
function allocateBacklog(queue,day,plan,days,usage={}){
 const eligible=queue.filter(q=>!q.mastered&&q.remaining>0&&q.created<=day.date&&(weekday(day.date)===0||day.subs.includes(q.subject)));
 eligible.sort((a,b)=>(a.priority==='high'?0:1)-(b.priority==='high'?0:1)||a.created.localeCompare(b.created));
 const used=Math.max(0,Number(usage.usedMinutes)||0),remainingSlots=Math.max(0,2-(Number(usage.usedChunks)||0));let available=Math.max(0,Math.min(plan.reserve+plan.extra,40)-used);const chunks=[];
 for(const q of eligible){if(available<=0||chunks.length>=remainingSlots)break;const min=Math.min(q.remaining,20,available);chunks.push({...q,allocated:min});available-=min;}
 return{chunks,eligibleCount:eligible.length,remainingMinutes:eligible.reduce((s,q)=>s+q.remaining,0),available:Math.max(0,plan.reserve+plan.extra-used),overflow:eligible.reduce((s,q)=>s+q.remaining,0)>Math.max(0,plan.reserve+plan.extra-used)};
}
function assessNight(settings){const c={...DEFAULTS,...settings};return Math.max(0,Number(c.politicsLesson)+Number(c.newWordsMinutes)-70)}
const API={NAMES,ROTATION,DEFAULTS,toMinutes,time,addDays,weekday,prettyMinutes,makePlan,lifeSlots,nextEligible,allocateBacklog,assessNight};
if(typeof module!=='undefined'&&module.exports)module.exports=API;root.StudyEngine=API;
})(typeof window!=='undefined'?window:globalThis);
